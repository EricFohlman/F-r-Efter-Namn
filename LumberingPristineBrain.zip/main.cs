using System;

class MainClass {
  public static void Main (string[] args) 
  {
 Console.Write("skriv förnamn: ");
 string Förnamn = Console.ReadLine();
 Console.Write  ("skriv efternamn: ");
 string Efternamn = Console.ReadLine();
 Console.Write("förnamn och efternamn: ");
 Console.Write (Förnamn + " " + Efternamn);
  }
}